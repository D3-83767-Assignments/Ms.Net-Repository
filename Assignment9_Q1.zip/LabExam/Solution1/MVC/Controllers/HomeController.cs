﻿using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Identity.Client;
using MVC.DAL;


namespace MVC.Controllers
{
    
    public class HomeController : Controller
    {
        IUsertbDBContext dbContext = null;
        public HomeController(IUsertbDBContext _dbContext)
        {
            dbContext = _dbContext;
        }

        public ViewResult Index()
        {
            List<Usertb> users = dbContext.GetUsers();
            return View(users);
        }

        public ViewResult Create()
        {
           
            return View();
        }





        
        public IActionResult AfterCreate(Usertb u)
        {
            int rowsAffected = dbContext.AddUsertb(u);
            if (rowsAffected > 0)
            {
                return Redirect("/Home/Index");
            }
            else
            {
                return null;
            }
        }

        public ViewResult Edit(int id)
        {
            try
            {
                Usertb uToEdit = dbContext.Search(id);
                if (uToEdit != null)
                {
                    return View(uToEdit);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return View("ErrorView", ex);
            }

        }

        public IActionResult Delete(int id)
        {
            int rowsAffected = dbContext.RemoveUsertb(id);

            if (rowsAffected > 0)
            {
                return Redirect("/Home/Index");
            }
            else
            {
                return null;
            }
        }




        public IActionResult AfterEdit(Usertb updatedUsertb)
        {
            int rowsAffected = dbContext.UpdateUsertb(updatedUsertb);
            if (rowsAffected > 0)
            {
                return Redirect("/Home/Index1");
            }
            else
            {
                return null;
            }
        }
    }
}


