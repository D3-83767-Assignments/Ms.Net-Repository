﻿using Microsoft.AspNetCore.Mvc;

namespace LiabraryManagementSystem.Views.Home
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
