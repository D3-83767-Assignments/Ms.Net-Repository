﻿namespace MVC.Models
{
    public class Book
    {
        public int id { get; set; }
        public string bname { get; set; } 

        public string author { get; set; }

        public string category { get; set; }
        
        public string price { get; set; }

       public string user_id { get; set; }

    }
}
