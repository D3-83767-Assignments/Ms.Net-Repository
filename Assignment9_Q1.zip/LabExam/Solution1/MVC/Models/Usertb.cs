﻿namespace MVC.Models
{
    public class Usertb
    {

        public int Uid { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Mob_No { get; set; }
        public string Password { get; set; }
     
    }
}
