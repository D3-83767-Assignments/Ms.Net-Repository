﻿namespace MVC.Models
{
    public class Movietb
    {

        public int Mid { get; set; }
        public string Moviename { get; set; }
        public string Actor { get; set; }
        public string Address { get; set; }
        public int Rating { get; set; }
        public int Uid { get; set; }

    }
}
