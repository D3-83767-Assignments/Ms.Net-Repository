﻿using MVC.Models;
using Microsoft.Data.SqlClient;

namespace MVC.DAL
{
    public interface IUsertbDBContext
    {
        int AddUsertb(Usertb u);
        List<Usertb> GetUsers();
        int RemoveUsertb(int id);
        Usertb Search(int id);
        int UpdateUsertb(Usertb updatedUsertb);
    }

    public class UsertbDBContext : IUsertbDBContext
    {
        public List<Usertb> GetUsers()
        {
            List<Usertb> users = new List<Usertb>();
            SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MVC;Integrated Security=True;Connect Timeout=30;Encrypt=False;");
            SqlCommand command = new SqlCommand("select * from Usert", connection);
            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Usertb u = new Usertb();
                u.Uid = Convert.ToInt32(reader["Uid"]);
                u.Username = reader["Username"].ToString();
                u.Email = reader["Email"].ToString();
                u.Mob_No = reader["Mob_No"].ToString();
                u.Password = reader["Password"].ToString();
                
              
                users.Add(u);
            }
            connection.Close();
            return users;
        }
        public int AddUsertb(Usertb u)
        {
            SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MVC;Integrated Security=True;Connect Timeout=30;Encrypt=False;");

            string queryTextFormat = "insert into Usert(Username,Email,Mob_No,Password) values('{1}','{2}','{3}','{4}')";
            string query = string.Format(queryTextFormat, u.Uid, u.Username,u.Email,u.Mob_No, u.Password);

            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();
            connection.Close();

            return rowsAffected;
        }






        public int UpdateUsertb(Usertb updatedUsertb)
        {
            SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=DAC_db;Integrated Security=True;Encrypt=False;");

            string queryTextFormat = "update usert set UserName='{1}, Email='{2}',MOb_No='{3}',Password='{4}' where Uid ={0}"; 

            string query = string.Format(queryTextFormat, updatedUsertb.Uid);

            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();
            connection.Close();

            return rowsAffected;
        }




        public int RemoveUsertb(int id)
        {
            SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MVC;Integrated Security=True;Connect Timeout=30;Encrypt=False;");

            string queryTextFormat = "delete from Usert where Uid = {0}";
            string query = string.Format(queryTextFormat, id);

            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();
            connection.Close();

            return rowsAffected;
        }


        public Usertb Search(int id)
        {
            List<Usertb> users = GetUsers();

            Usertb uToEdit = (from u in users
                             where u.Uid == id
                             select u).First();

            return uToEdit;
        }
    }
}
